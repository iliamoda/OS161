vfsfail.o: ../../vfs/vfsfail.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/kern/errno.h \
 ../../include/vnode.h ../../include/spinlock.h ../../include/cdefs.h \
 ../../include/hangman.h opt-hangman.h includelinks/machine/spinlock.h
