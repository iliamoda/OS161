sys_execv.o: ../../syscall/sys_execv.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/limits.h \
 ../../include/kern/limits.h ../../include/kern/errno.h \
 ../../include/kern/fcntl.h ../../include/proc.h ../../include/spinlock.h \
 ../../include/cdefs.h ../../include/hangman.h opt-hangman.h \
 includelinks/machine/spinlock.h ../../include/thread.h \
 ../../include/array.h ../../include/lib.h opt-noasserts.h \
 ../../include/threadlist.h includelinks/machine/thread.h \
 ../../include/setjmp.h includelinks/kern/machine/setjmp.h \
 ../../include/current.h includelinks/machine/current.h \
 ../../include/syscall.h ../../include/vnode.h ../../include/vfs.h \
 ../../include/addrspace.h ../../include/vm.h includelinks/machine/vm.h \
 opt-dumbvm.h ../../include/copyinout.h ../../include/file_table.h
