sfs_bmap.o: ../../fs/sfs/sfs_bmap.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/kern/errno.h \
 ../../include/lib.h ../../include/cdefs.h opt-noasserts.h \
 ../../include/vfs.h ../../include/array.h ../../include/sfs.h \
 ../../include/fs.h ../../include/vnode.h ../../include/spinlock.h \
 ../../include/hangman.h opt-hangman.h includelinks/machine/spinlock.h \
 ../../include/kern/sfs.h ../../fs/sfs/sfsprivate.h ../../include/uio.h \
 ../../include/kern/iovec.h
