// file_table.h
#ifndef FILE_TABLE_H
#define FILE_TABLE_H

#include <types.h>
#include <vnode.h>



#endif /* FILE_TABLE_H */
